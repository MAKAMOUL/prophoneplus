import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  type User as FirebaseUser,
} from 'firebase/auth';
import { doc, getDoc, setDoc, Timestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { localDb } from '../lib/db';
import type { User } from '../types';

const DEMO_USERS: Record<string, { password: string; user: User }> = {
  'admin@prophoneplus.com': {
    password: 'Admin123!',
    user: {
      id: 'demo-admin-001',
      email: 'admin@prophoneplus.com',
      role: 'admin',
      name: 'Admin User',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  },
  'worker@prophoneplus.com': {
    password: 'Worker123!',
    user: {
      id: 'demo-worker-001',
      email: 'worker@prophoneplus.com',
      role: 'worker',
      name: 'Worker User',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  },
};

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  createWorker: (email: string, password: string, name: string) => Promise<void>;
  isAdmin: boolean;
  isWorker: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}

interface AuthProviderProps {
  children: ReactNode;
}

const AUTH_STORAGE_KEY = 'prophoneplus_auth';

async function getUserData(firebaseUser: FirebaseUser): Promise<User | null> {
  try {
    const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
    if (userDoc.exists()) {
      const data = userDoc.data();
      return {
        id: firebaseUser.uid,
        email: data.email || firebaseUser.email || '',
        role: data.role || 'worker',
        name: data.name || firebaseUser.displayName || 'User',
        createdAt: data.createdAt?.toMillis?.() || Date.now(),
        updatedAt: data.updatedAt?.toMillis?.() || Date.now(),
      };
    }

    const newUser: User = {
      id: firebaseUser.uid,
      email: firebaseUser.email || '',
      role: 'worker',
      name: firebaseUser.displayName || 'User',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    await setDoc(doc(db, 'users', firebaseUser.uid), {
      ...newUser,
      createdAt: Timestamp.fromMillis(newUser.createdAt),
      updatedAt: Timestamp.fromMillis(newUser.updatedAt),
    });
    return newUser;
  } catch (error) {
    console.error('Error fetching user data:', error);
    return null;
  }
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY);
    if (stored) {
      try {
        const userData = JSON.parse(stored) as User;
        setUser(userData);
      } catch {
        localStorage.removeItem(AUTH_STORAGE_KEY);
      }
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userData = await getUserData(firebaseUser);
        if (userData) {
          await localDb.users.put(userData);
          localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData));
          setUser(userData);
        }
      } else {
        const storedUser = localStorage.getItem(AUTH_STORAGE_KEY);
        if (!storedUser) {
          setUser(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signIn = async (email: string, password: string): Promise<void> => {
    const normalizedEmail = email.toLowerCase().trim();

    const demoAccount = DEMO_USERS[normalizedEmail];
    if (demoAccount && demoAccount.password === password) {
      await localDb.users.put(demoAccount.user);
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(demoAccount.user));
      setUser(demoAccount.user);
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, normalizedEmail, password);
      const userData = await getUserData(userCredential.user);
      if (userData) {
        await localDb.users.put(userData);
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData));
        setUser(userData);
      }
    } catch (firebaseError) {
      const existingUser = await localDb.users
        .where('email')
        .equals(normalizedEmail)
        .first();

      if (existingUser) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(existingUser));
        setUser(existingUser);
        return;
      }

      throw firebaseError;
    }
  };

  const signOut = async (): Promise<void> => {
    try {
      await firebaseSignOut(auth);
    } catch (error) {
      console.error('Firebase sign out error:', error);
    }
    localStorage.removeItem(AUTH_STORAGE_KEY);
    setUser(null);
  };

  const createWorker = async (
    email: string,
    password: string,
    name: string
  ): Promise<void> => {
    const normalizedEmail = email.toLowerCase().trim();

    const existing = await localDb.users
      .where('email')
      .equals(normalizedEmail)
      .first();

    if (existing) {
      throw new Error('User with this email already exists');
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, normalizedEmail, password);

      const newWorker: User = {
        id: userCredential.user.uid,
        email: normalizedEmail,
        role: 'worker',
        name,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      await setDoc(doc(db, 'users', userCredential.user.uid), {
        ...newWorker,
        createdAt: Timestamp.fromMillis(newWorker.createdAt),
        updatedAt: Timestamp.fromMillis(newWorker.updatedAt),
      });
      await localDb.users.put(newWorker);
    } catch (error) {
      const newWorker: User = {
        id: `worker-${Date.now()}`,
        email: normalizedEmail,
        role: 'worker',
        name,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      await localDb.users.put(newWorker);

      DEMO_USERS[normalizedEmail] = {
        password,
        user: newWorker,
      };
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    signIn,
    signOut,
    createWorker,
    isAdmin: user?.role === 'admin',
    isWorker: user?.role === 'worker',
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
