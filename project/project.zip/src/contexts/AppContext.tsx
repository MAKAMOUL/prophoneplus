import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import { localDb } from '../lib/db';
import { supabase } from '../lib/supabase';
import { setSyncCallback, getOnlineStatus } from '../lib/sync';
import type { Product, Category, Sale, Alert, SyncStatus } from '../types';
import { useAuth } from './AuthContext';

interface AppContextType {
  products: Product[];
  categories: Category[];
  sales: Sale[];
  alerts: Alert[];
  syncStatus: SyncStatus;
  refreshData: () => Promise<void>;
  dismissAlert: (alertId: string) => Promise<void>;
  getLowStockProducts: () => Product[];
}

const AppContext = createContext<AppContextType | null>(null);

export function useApp(): AppContextType {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}

interface AppProviderProps {
  children: ReactNode;
}

export function AppProvider({ children }: AppProviderProps) {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(
    getOnlineStatus() ? 'online' : 'offline'
  );

  const refreshData = useCallback(async () => {
    try {
      const { data: supabaseProducts, error } = await supabase
        .from('products')
        .select('*');

      if (!error && supabaseProducts && supabaseProducts.length > 0) {
        const mappedProducts: Product[] = supabaseProducts.map((sp) => ({
          id: sp.id,
          ref: sp.ref,
          name: sp.product_name,
          category: sp.category,
          subcategory: sp.subcategory,
          quantity: sp.quantity_remaining ?? sp.quantity,
          quantityRemaining: sp.quantity_remaining,
          price: sp.price || 0,
          minStock: sp.min_stock || 5,
          createdBy: sp.inserted_by || '',
          createdAt: new Date(sp.created_at).getTime(),
          updatedAt: new Date(sp.updated_at).getTime(),
          synced: true,
          deleted: false,
        }));

        setProducts(mappedProducts);

        await localDb.products.clear();
        await localDb.alerts.clear();
        for (const product of mappedProducts) {
          await localDb.products.put(product);
        }

        const uniqueCategories = [...new Set(mappedProducts.map((p) => p.category).filter(Boolean))];
        const categoryObjects: Category[] = uniqueCategories.map((name, index) => ({
          id: `cat-${index}`,
          name,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          synced: true,
        }));
        setCategories(categoryObjects);

        await checkLowStock(mappedProducts);
      } else {
        const [productsData, categoriesData] = await Promise.all([
          localDb.products.filter((p) => !p.deleted).toArray(),
          localDb.categories.filter((c) => !c.deleted).toArray(),
        ]);
        setProducts(productsData);
        setCategories(categoriesData);
        await checkLowStock(productsData);
      }

      const [salesData, alertsData] = await Promise.all([
        localDb.sales.toArray(),
        localDb.alerts.filter((a) => !a.dismissed).toArray(),
      ]);
      setSales(salesData);
      setAlerts(alertsData);
    } catch (error) {
      console.error('Error refreshing data:', error);
      const [productsData, categoriesData, salesData, alertsData] =
        await Promise.all([
          localDb.products.filter((p) => !p.deleted).toArray(),
          localDb.categories.filter((c) => !c.deleted).toArray(),
          localDb.sales.toArray(),
          localDb.alerts.filter((a) => !a.dismissed).toArray(),
        ]);
      setProducts(productsData);
      setCategories(categoriesData);
      setSales(salesData);
      setAlerts(alertsData);
    }
  }, []);

  const checkLowStock = async (productsList: Product[]) => {
    const lowStockProducts = productsList.filter(
      (p) => p.quantity <= p.minStock && !p.deleted
    );

    for (const product of lowStockProducts) {
      const existingAlert = await localDb.alerts
        .where('productId')
        .equals(product.id)
        .first();

      if (!existingAlert || existingAlert.dismissed) {
        const alert: Alert = {
          id: `alert-${product.id}-${Date.now()}`,
          productId: product.id,
          productName: product.name,
          currentQuantity: product.quantity,
          minStock: product.minStock,
          createdAt: Date.now(),
          dismissed: false,
        };

        if (existingAlert) {
          await localDb.alerts.update(existingAlert.id, {
            currentQuantity: product.quantity,
            dismissed: false,
          });
        } else {
          await localDb.alerts.add(alert);
        }
      }
    }

    const updatedAlerts = await localDb.alerts
      .filter((a) => !a.dismissed)
      .toArray();
    setAlerts(updatedAlerts);
  };

  const dismissAlert = async (alertId: string) => {
    await localDb.alerts.update(alertId, { dismissed: true });
    setAlerts((prev) => prev.filter((a) => a.id !== alertId));
  };

  const getLowStockProducts = useCallback(() => {
    return products.filter((p) => p.quantity <= p.minStock && !p.deleted);
  }, [products]);

  useEffect(() => {
    setSyncCallback((status) => {
      setSyncStatus(status);
      if (status === 'online') {
        refreshData();
      }
    });
  }, [refreshData]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  useEffect(() => {
    if (user) {
      refreshData();
    }
  }, [user, refreshData]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshData();
    }, 10000);

    return () => clearInterval(interval);
  }, [refreshData]);

  const value: AppContextType = {
    products,
    categories,
    sales,
    alerts,
    syncStatus,
    refreshData,
    dismissAlert,
    getLowStockProducts,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
