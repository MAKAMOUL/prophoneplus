import { useState } from 'react';
import {
  Search,
  Download,
  Package,
  AlertTriangle,
  ShoppingCart,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { exportProductsToExcel } from '../../lib/excel';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/common/Button';

export default function WorkerProducts() {
  const { products, categories } = useApp();
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const navigate = useNavigate();

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(search.toLowerCase()) ||
      product.category.toLowerCase().includes(search.toLowerCase());
    const matchesCategory =
      !categoryFilter || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleExport = async () => {
    try {
      await exportProductsToExcel(products);
    } catch (error) {
      console.error('Export error:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-gray-900">{t.products.title}</h1>
        <Button
          size="sm"
          variant="secondary"
          icon={<Download className="w-4 h-4" />}
          onClick={handleExport}
        >
          {t.common.export}
        </Button>
      </div>

      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder={t.products.searchProducts}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
        >
          <option value="">{t.products.allCategories}</option>
          {categories.map((cat) => (
            <option key={cat.id} value={cat.name}>
              {cat.name}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-3">
        {filteredProducts.map((product) => {
          const isLowStock = product.quantity <= product.minStock;
          return (
            <div
              key={product.id}
              className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
            >
              <div className="flex gap-4">
                <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                  {product.imageUrl || product.imageData ? (
                    <img
                      src={product.imageUrl || product.imageData}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Package className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 truncate">
                    {product.name}
                  </h3>
                  <p className="text-sm text-gray-500">{product.category}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span
                      className={`text-sm font-medium ${
                        isLowStock ? 'text-red-600' : 'text-gray-600'
                      }`}
                    >
                      {isLowStock && (
                        <AlertTriangle className="inline w-4 h-4 mr-1" />
                      )}
                      {product.quantity} {language === 'fr' ? 'en stock' : 'in stock'}
                    </span>
                    <span className="text-lg font-bold text-blue-600">
                      ${product.price.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() =>
                  navigate('/worker/sell', { state: { product } })
                }
                disabled={product.quantity === 0}
                className="w-full mt-3 flex items-center justify-center gap-2 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                {language === 'fr' ? 'Vendre' : 'Sell'}
              </button>
            </div>
          );
        })}

        {filteredProducts.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl">
            <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">{t.products.noProducts}</p>
          </div>
        )}
      </div>
    </div>
  );
}
