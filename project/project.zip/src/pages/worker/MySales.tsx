import { useState } from 'react';
import { Search, Download, ShoppingCart, Calendar } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { exportSalesToExcel } from '../../lib/excel';
import Button from '../../components/common/Button';

export default function MySales() {
  const { sales } = useApp();
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('all');

  const mySales = sales.filter((sale) => sale.soldBy === user?.id);

  const filteredSales = mySales
    .filter((sale) => {
      const matchesSearch = sale.productName
        .toLowerCase()
        .includes(search.toLowerCase());

      let matchesDate = true;
      if (dateFilter !== 'all') {
        const saleDate = new Date(sale.createdAt);
        const today = new Date();

        if (dateFilter === 'today') {
          matchesDate = saleDate.toDateString() === today.toDateString();
        } else if (dateFilter === 'week') {
          const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
          matchesDate = saleDate >= weekAgo;
        } else if (dateFilter === 'month') {
          matchesDate =
            saleDate.getMonth() === today.getMonth() &&
            saleDate.getFullYear() === today.getFullYear();
        }
      }

      return matchesSearch && matchesDate;
    })
    .sort((a, b) => b.createdAt - a.createdAt);

  const totalRevenue = filteredSales.reduce(
    (sum, sale) => sum + sale.totalPrice,
    0
  );

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString(language === 'fr' ? 'fr-FR' : 'en-US', {
      minimumFractionDigits: 2,
      style: 'currency',
      currency: 'USD',
    });
  };

  const handleExport = async () => {
    try {
      await exportSalesToExcel(filteredSales, 'my-sales');
    } catch (error) {
      console.error('Export error:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-gray-900">{t.sales.mySales}</h1>
        <Button
          size="sm"
          variant="secondary"
          icon={<Download className="w-4 h-4" />}
          onClick={handleExport}
        >
          {t.common.export}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">{t.dashboard.totalSales}</p>
          <p className="text-2xl font-bold text-gray-900">
            {filteredSales.length}
          </p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">{t.dashboard.totalRevenue}</p>
          <p className="text-2xl font-bold text-green-600">
            {formatCurrency(totalRevenue)}
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder={t.sales.searchSales}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
          />
        </div>

        <select
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
        >
          <option value="all">{t.sales.allTime}</option>
          <option value="today">{t.sales.today}</option>
          <option value="week">{t.sales.thisWeek}</option>
          <option value="month">{t.sales.thisMonth}</option>
        </select>
      </div>

      <div className="space-y-3">
        {filteredSales.map((sale) => (
          <div
            key={sale.id}
            className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <ShoppingCart className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">
                    {sale.productName}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {sale.quantity} x {formatCurrency(sale.unitPrice)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-green-600">
                  {formatCurrency(sale.totalPrice)}
                </p>
                <div className="flex items-center gap-1 text-xs text-gray-400 mt-1">
                  <Calendar className="w-3 h-3" />
                  <span>{new Date(sale.createdAt).toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US')}</span>
                </div>
              </div>
            </div>
          </div>
        ))}

        {filteredSales.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl">
            <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">{t.sales.noSalesYet}</p>
          </div>
        )}
      </div>
    </div>
  );
}
