import { supabase } from './supabase';
import { localDb } from './db';
import type { Product, Category, Sale, SyncStatus } from '../types';
import { v4 as uuidv4 } from 'uuid';

type SyncCallback = (status: SyncStatus) => void;

let syncCallback: SyncCallback | null = null;
let isOnline = navigator.onLine;
let isSyncing = false;

export function setSyncCallback(callback: SyncCallback): void {
  syncCallback = callback;
}

export function getOnlineStatus(): boolean {
  return isOnline;
}

function updateStatus(status: SyncStatus): void {
  if (syncCallback) {
    syncCallback(status);
  }
}

window.addEventListener('online', () => {
  isOnline = true;
  updateStatus('online');
  syncAllData();
});

window.addEventListener('offline', () => {
  isOnline = false;
  updateStatus('offline');
});

export async function syncAllData(): Promise<void> {
  if (!isOnline || isSyncing) return;

  isSyncing = true;
  updateStatus('syncing');

  try {
    await syncProductsFromSupabase();
    await syncCategories();
    await syncSales();
    updateStatus('online');
  } catch (error) {
    console.error('Sync error:', error);
    updateStatus(isOnline ? 'online' : 'offline');
  } finally {
    isSyncing = false;
  }
}

async function syncProductsFromSupabase(): Promise<void> {
  try {
    const { data: supabaseProducts, error } = await supabase
      .from('products')
      .select('*');

    if (error) {
      console.error('Failed to fetch products from Supabase:', error);
      return;
    }

    if (supabaseProducts) {
      for (const sp of supabaseProducts) {
        const localProduct = await localDb.products.get(sp.id);

        const mappedProduct: Product = {
          id: sp.id,
          ref: sp.ref,
          name: sp.product_name,
          category: sp.category,
          subcategory: sp.subcategory,
          quantity: sp.quantity,
          quantityRemaining: sp.quantity_remaining,
          price: sp.price || 0,
          minStock: sp.min_stock || 5,
          createdBy: sp.inserted_by || '',
          createdAt: new Date(sp.created_at).getTime(),
          updatedAt: new Date(sp.updated_at).getTime(),
          synced: true,
          deleted: false,
        };

        if (!localProduct) {
          await localDb.products.add(mappedProduct);
        } else {
          const supabaseUpdatedAt = new Date(sp.updated_at).getTime();
          if (supabaseUpdatedAt > localProduct.updatedAt || localProduct.synced) {
            await localDb.products.update(sp.id, mappedProduct);
          }
        }
      }
    }

    const unsyncedProducts = await localDb.products.where('synced').equals(0).toArray();
    for (const product of unsyncedProducts) {
      try {
        if (product.deleted) {
          await supabase.from('products').delete().eq('id', product.id);
        } else {
          const { error: upsertError } = await supabase.from('products').upsert({
            id: product.id,
            ref: product.ref || `STK${Date.now()}`,
            product_name: product.name,
            category: product.category,
            subcategory: product.subcategory || '',
            quantity: product.quantity,
            quantity_remaining: product.quantityRemaining ?? product.quantity,
            price: product.price,
            min_stock: product.minStock,
            inserted_by: product.createdBy,
            updated_at: new Date(product.updatedAt).toISOString(),
          });

          if (upsertError) {
            console.error(`Failed to sync product ${product.id}:`, upsertError);
            continue;
          }
        }
        await localDb.products.update(product.id, { synced: true });
      } catch (error) {
        console.error(`Failed to sync product ${product.id}:`, error);
      }
    }
  } catch (error) {
    console.error('Failed to sync products:', error);
  }
}

async function syncCategories(): Promise<void> {
  const categories = await localDb.categories.toArray();
  const uniqueCategories = new Set<string>();

  const { data: supabaseProducts } = await supabase
    .from('products')
    .select('category');

  if (supabaseProducts) {
    for (const p of supabaseProducts) {
      if (p.category) {
        uniqueCategories.add(p.category);
      }
    }
  }

  for (const catName of uniqueCategories) {
    const existing = categories.find((c) => c.name === catName);
    if (!existing) {
      await localDb.categories.add({
        id: uuidv4(),
        name: catName,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        synced: true,
      });
    }
  }
}

async function syncSales(): Promise<void> {
  const unsyncedSales = await localDb.sales.where('synced').equals(0).toArray();

  for (const sale of unsyncedSales) {
    try {
      await localDb.sales.update(sale.id, { synced: true });
    } catch (error) {
      console.error(`Failed to sync sale ${sale.id}:`, error);
    }
  }
}

export async function addProduct(product: Omit<Product, 'id' | 'synced' | 'createdAt' | 'updatedAt'>): Promise<Product> {
  const now = Date.now();
  const id = uuidv4();
  const ref = `STK${now}${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

  const newProduct: Product = {
    ...product,
    id,
    ref,
    createdAt: now,
    updatedAt: now,
    synced: false,
  };

  await localDb.products.add(newProduct);

  if (isOnline) {
    try {
      const { error } = await supabase.from('products').insert({
        id,
        ref,
        product_name: product.name,
        category: product.category,
        subcategory: product.subcategory || '',
        quantity: product.quantity,
        quantity_remaining: product.quantity,
        price: product.price,
        min_stock: product.minStock,
        inserted_by: product.createdBy,
      });

      if (!error) {
        await localDb.products.update(id, { synced: true });
      }
    } catch (error) {
      console.error('Failed to add product to Supabase:', error);
    }
  }

  return newProduct;
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<void> {
  const now = Date.now();

  await localDb.products.update(id, {
    ...updates,
    updatedAt: now,
    synced: false,
  });

  if (isOnline) {
    try {
      const supabaseUpdates: Record<string, unknown> = {
        updated_at: new Date(now).toISOString(),
      };

      if (updates.name !== undefined) supabaseUpdates.product_name = updates.name;
      if (updates.category !== undefined) supabaseUpdates.category = updates.category;
      if (updates.subcategory !== undefined) supabaseUpdates.subcategory = updates.subcategory;
      if (updates.quantity !== undefined) {
        supabaseUpdates.quantity = updates.quantity;
        supabaseUpdates.quantity_remaining = updates.quantity;
      }
      if (updates.price !== undefined) supabaseUpdates.price = updates.price;
      if (updates.minStock !== undefined) supabaseUpdates.min_stock = updates.minStock;

      const { error } = await supabase.from('products').update(supabaseUpdates).eq('id', id);

      if (!error) {
        await localDb.products.update(id, { synced: true });
      }
    } catch (error) {
      console.error('Failed to update product in Supabase:', error);
    }
  }
}

export async function deleteProduct(id: string): Promise<void> {
  await localDb.products.update(id, {
    deleted: true,
    updatedAt: Date.now(),
    synced: false,
  });

  if (isOnline) {
    try {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (!error) {
        await localDb.products.delete(id);
      }
    } catch (error) {
      console.error('Failed to delete product from Supabase:', error);
    }
  }
}

export async function addCategory(name: string): Promise<Category> {
  const now = Date.now();
  const newCategory: Category = {
    id: uuidv4(),
    name,
    createdAt: now,
    updatedAt: now,
    synced: true,
  };

  await localDb.categories.add(newCategory);
  return newCategory;
}

export async function updateCategory(id: string, name: string): Promise<void> {
  await localDb.categories.update(id, {
    name,
    updatedAt: Date.now(),
    synced: true,
  });
}

export async function deleteCategory(id: string): Promise<void> {
  await localDb.categories.update(id, {
    deleted: true,
    updatedAt: Date.now(),
    synced: true,
  });
}

export async function addSale(sale: Omit<Sale, 'id' | 'synced' | 'createdAt'>): Promise<Sale> {
  const newSale: Sale = {
    ...sale,
    id: uuidv4(),
    createdAt: Date.now(),
    synced: false,
  };

  await localDb.sales.add(newSale);

  const product = await localDb.products.get(sale.productId);
  if (product) {
    const newQuantity = product.quantity - sale.quantity;
    await updateProduct(sale.productId, {
      quantity: newQuantity,
    });
  }

  return newSale;
}

export async function saveProductImage(productId: string, imageData: string): Promise<void> {
  await localDb.images.put({
    id: productId,
    data: imageData,
    synced: false,
  });

  await localDb.products.update(productId, {
    imageData,
    synced: false,
  });
}

export async function getProductImage(productId: string): Promise<string | null> {
  const image = await localDb.images.get(productId);
  return image?.data || null;
}
